create procedure find_category(mCat fashion.masterCategory%type) is
v_rec fashion%rowtype;
begin 
for v_rec in (select id, gender, subcategory, status 
from fashion where masterCategory = mCat)
loop
dbms_output.put_line(v_rec.id|| ' ' || v_rec.gender|| ' ' || v_rec.subcategory|| ' ' || v_rec.status);
end loop;
end;
/

