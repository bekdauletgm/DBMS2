create trigger TR_ADD
    after update of GENDER
    on FASHION
    for each row
declare
v_gen varchar2(45):='Men';
begin 
IF(:NEW.GENDER='Women') then delete from men_item where id=:New.id;
end if;
end;
/

