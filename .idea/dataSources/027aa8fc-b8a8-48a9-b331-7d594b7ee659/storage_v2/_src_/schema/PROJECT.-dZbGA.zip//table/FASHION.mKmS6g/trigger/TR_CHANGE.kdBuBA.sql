create trigger TR_CHANGE
    before insert or update or delete
    on FASHION
    for each row
declare 
v_user varchar2(45);
begin
select user into v_user from dual;
if inserting then
dbms_output.put_line('One row inserted by '|| ' ' || v_user);
elsif deleting then
dbms_output.put_line('One row deleted by '|| ' ' || v_user);
elsif updating then
dbms_output.put_line('One row updated by '|| ' ' || v_user);
end if;
end;
/

