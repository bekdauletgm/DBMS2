create FUNCTION get_sold(st varchar2) 
   RETURN NUMBER 
   IS sold_numb NUMBER(11,2);
   BEGIN 
      SELECT count(*)
      INTO sold_numb 
      FROM fashion 
      WHERE status = st; 
      RETURN(sold_numb); 
    END;
/

