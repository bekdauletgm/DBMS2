create procedure find_subCat(sCat fashion.subCategory%type) is
v_rec fashion%rowtype;
sql_qry varchar2(250);

sec_qry varchar2(250);
begin 
sql_qry:= 'create table topwear (
            id number(38,0),
            gender varchar2(26),
            subcategory varchar2(26),
            status varchar2(26)
            )';

execute immediate sql_qry;            
for v_rec in (select id, gender, subcategory, status 
from fashion where subCategory = sCat)
loop
insert into topwear(id, gender, subcategory, status) values (v_rec.id, v_rec.gender, v_rec.subcategory, v_rec.status);      
dbms_output.put_line(v_rec.id|| ' ' || v_rec.gender|| ' ' || v_rec.subcategory|| ' ' || v_rec.status);
end loop;
end;
/

