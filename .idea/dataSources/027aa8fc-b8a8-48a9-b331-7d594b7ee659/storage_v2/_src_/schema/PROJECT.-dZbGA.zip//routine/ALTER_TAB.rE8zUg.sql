create procedure alter_tab(filename varchar2, v_type varchar2) as
begin
execute immediate 'alter table fashion
add('||filename ||' '|| v_type|| ')';
end;
/

