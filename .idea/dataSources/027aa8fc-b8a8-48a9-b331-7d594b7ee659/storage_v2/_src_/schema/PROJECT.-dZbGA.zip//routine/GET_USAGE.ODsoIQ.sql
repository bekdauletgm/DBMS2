create FUNCTION get_usage(st varchar2) 
   RETURN NUMBER 
   IS usage_numb NUMBER(11,2);
   BEGIN 
      SELECT count(*)
      INTO usage_numb 
      FROM fashion 
      WHERE usage = st; 
      RETURN(usage_numb); 
    END;
/

