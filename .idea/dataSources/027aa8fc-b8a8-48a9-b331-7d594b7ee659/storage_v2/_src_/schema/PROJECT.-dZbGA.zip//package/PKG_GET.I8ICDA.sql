create package pkg_get
is
function get_inf(gen varchar2) return number;
function get_usage(st varchar2) return  number;
function get_sold(st varchar2) return  number;
end pkg_get;
/

