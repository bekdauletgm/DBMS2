create FUNCTION get_inf(gen varchar2) 
   RETURN NUMBER 
   IS inf_numb NUMBER(11,2);
   BEGIN 
      SELECT count(*)
      INTO inf_numb 
      FROM fashion 
      WHERE gender = gen; 
      RETURN(inf_numb); 
    END;
/

