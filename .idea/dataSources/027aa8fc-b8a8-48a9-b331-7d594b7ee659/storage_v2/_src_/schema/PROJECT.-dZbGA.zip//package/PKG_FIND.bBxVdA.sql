create package pkg_find
is
procedure find_category(mCat fashion.masterCategory%type);
procedure find_subCat(sCat fashion.masterCategory%type);
end pkg_find;
/

