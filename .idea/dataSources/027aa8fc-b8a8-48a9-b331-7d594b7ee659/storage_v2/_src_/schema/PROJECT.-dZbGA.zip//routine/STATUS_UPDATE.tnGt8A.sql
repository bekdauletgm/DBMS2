create procedure status_update(id number, st varchar2) as
begin
execute immediate 'update fashion set status = '|| st ||' where id = '|| id || ';';
--update fashion set status = 'discounts' where id = 15970;
end;



declare 
ID number:=15970;
st varchar2(45):='sold out';
begin
status_update(id, st);
end;

create or replace procedure row_delete(id number) as
begin
execute immediate 'delete from fashion where id = ' || id;
end;


declare
id number:= 39386;
begin
row_delete(id);
end;


create or replace procedure alter_tab(filename varchar2, type varchar2) as
begin
execute immediate 'alter table fashion
add('||filename || type|| ')';
end;
/

