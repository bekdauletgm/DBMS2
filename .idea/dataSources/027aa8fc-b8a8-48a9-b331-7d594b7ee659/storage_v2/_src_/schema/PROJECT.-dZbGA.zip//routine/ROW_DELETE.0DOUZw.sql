create procedure row_delete(id number) as
begin
execute immediate 'delete from fashion where id = ' || id;
end;
/

