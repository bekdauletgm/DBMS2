create procedure table_delete(table_name varchar2) as
begin
execute immediate 'delete from' || table_name;
end;
/

