create trigger TR_DELETE
    after update of GENDER
    on FASHION
    for each row
begin  

IF(:NEW.GENDER='Women') then delete from men_item where id=:New.id; 

end if; 

end;
/

